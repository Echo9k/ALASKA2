from setuptools import setup

setup(name='stego-pack',
      version='0.0.2',
      description='Helper functions to download, unzip, and augment images for steganalisis',
      packages=['stego'],
      zip_safe=False)
